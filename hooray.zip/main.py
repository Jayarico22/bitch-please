# Main backend logic for Erin's server
print('Erin Server is live.')